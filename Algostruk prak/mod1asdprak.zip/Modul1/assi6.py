from assi5 import primeChecker as pc

for i in range(0, 1001):
    print(f"Angka {i} = {pc(i)}")